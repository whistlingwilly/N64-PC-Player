# N64 Operator — v0.3.1

> Like Epilogue's GB/SN Operator, but for Nintendo 64.

Plug in your DreamDump64, insert a cartridge, and the game launches automatically.

---

## Option A — Single EXE (recommended)

Run `BUILD.bat` once. It creates `dist\N64Operator.exe`.
After that, just double-click the EXE — no Python, no terminal, nothing else.

```
BUILD.bat
```

Then copy `dist\N64Operator.exe` anywhere you like.

---

## Option B — Run from source

```bat
python -m venv venv
venv\Scripts\activate
pip install PyQt6 pyusb
python main.py
```

---

## How it works

1. Launch N64 Operator — shows "Searching…"
2. Plug in DreamDump64 via USB — it mounts as a drive automatically
3. Insert a cartridge — the device dumps the ROM to the drive
4. App detects the ROM file and identifies the game
5. Click **PLAY** — Mupen64Plus launches with your game

---

## Mupen64Plus (emulator)

N64 Operator needs Mupen64Plus to actually play games.

| Platform | Install |
|----------|---------|
| Windows  | https://mupen64plus.org/ or `winget install mupen64plus` |
| macOS    | `brew install mupen64plus` |
| Linux    | `sudo apt install mupen64plus` |

The app will tell you if it's not found.
